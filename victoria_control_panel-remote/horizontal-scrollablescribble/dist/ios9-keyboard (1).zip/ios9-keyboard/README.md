# iOS9 Keyboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/eJOKNo](https://codepen.io/jkantner/pen/eJOKNo).

iPhone keyboard from iOS9 recreated in HTML, CSS, and jQuery. Not 100% accurate, but very close!

Update 3/15/21: Updated jQuery version